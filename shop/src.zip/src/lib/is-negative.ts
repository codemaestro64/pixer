export function isNegative(value: number) {
  return value < 0;
}
