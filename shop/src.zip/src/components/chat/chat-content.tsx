import { useTranslation } from 'next-i18next';
import Input from '@/components/ui/forms/input';
import { useState } from 'react';
import { AttachmentIcon } from '@/components/icons/chat/attachment-icon';
import { SendIcon } from '@/components/icons/chat/send-icon';
import { SpeechIcon } from '@/components/icons/chat/speech-icon';
import { AudioPlayIcon } from '@/components/icons/chat/audio-play-icon';
import { AudioPauseIcon } from '@/components/icons/chat/audio-pause-icon';
import { PhoneCallIcon } from '@/components/icons/chat/phone-call-icon';
import { VideoCallIcon } from '@/components/icons/chat/video-call-icon';
import Scrollbar from '@/components/ui/scrollbar';
import { DoubleTickIcon } from '@/components/icons/chat/double-tick-icon';

import Image from '@/components/ui/image';
import Button from '@/components/ui/button';

import sampleAvatar1 from '@/assets/images/avatars/1.png';

const ChatContent = () => {
  const { t } = useTranslation('common');
  const [message, setMessageText] = useState('');

  return (
    <div className="hidden h-full w-full grow border-r-[1px] border-light-400 dark:border-dark-300 sm:block">
      <div className="flex h-full flex-col">
        <div className="flex flex-col px-4">
          <div className="mt-10 py-3 sm:py-4">
            <div className="flex items-center space-x-2">
              <div className="flex-shrink-0">
                <div className="h-[50px] w-[50px]">
                  <Image
                    alt="avatar"
                    quality={100}
                    objectFit="cover"
                    src={sampleAvatar1}
                    className="rounded-full bg-light-500 dark:bg-dark-300"
                  />
                </div>
              </div>
              <div className="min-w-0 flex-1">
                <p className="mb-2 min-w-0 items-center truncate text-xl font-medium text-gray-900 dark:text-white">
                  Neil Sims
                </p>

                <div className="flex min-w-0 flex-row items-center">
                  <p className="mb-2 items-center truncate text-sm text-gray-500 dark:text-gray-400">
                    Active Now
                  </p>
                  <p className="-mt-2 ml-1 inline-flex min-h-[16px] min-w-[16px] shrink-0 items-center justify-center rounded-full border-2 border-light-100 bg-brand px-0.5 text-10px font-bold leading-none text-light dark:border-dark-250" />
                </div>
              </div>
              <div className="inline-flex gap-4 text-xs font-semibold text-gray-500 dark:text-gray-400">
                <PhoneCallIcon className="h-[20px] w-[20px] text-dark-800" />
                <VideoCallIcon className="h-[20px] w-[20px] text-dark-800" />
              </div>
            </div>
          </div>
        </div>

        <div className="mt-10 h-[2px] bg-light-400 px-4 dark:bg-dark-300 " />

        <Scrollbar className="relative h-full w-full px-4">
          <div className="flex w-full flex-col ">
            <div className=" mt-4 flex flex-row gap-2">
              <div className="flex items-end justify-center">
                <div className="relative h-[50px] w-[50px]">
                  <Image
                    alt="avatar"
                    quality={100}
                    objectFit="cover"
                    src={sampleAvatar1}
                    className="rounded-full bg-light-500 dark:bg-dark-300"
                  />
                  <span className="absolute top-0 right-0 flex min-h-[12px] min-w-[12px] shrink-0 items-center justify-center rounded-full border-2 border-light-100 bg-brand px-0.5 text-10px font-bold leading-none text-light" />
                </div>
              </div>

              <div className="flex max-w-[200px] items-end md:max-w-sm lg:max-w-3xl">
                <div className="bg-white-100 relative flex shrink flex-row items-center justify-between rounded-tl-[20px] rounded-tr-[20px] rounded-br-[20px] bg-light-400 px-4 py-2 pr-6  dark:bg-dark-400">
                  <div className="text-left text-[16px] text-gray-500 dark:text-gray-400">
                    OoOo, Yeah, Thanks really Cool! OoOo, Yeah, Thanks really
                    Cool! OoOo, Yeah, Thanks really Cool! OoOo, Yeah, Thanks
                    really Cool!
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 flex flex-col">
              <div className="flex flex-row items-center justify-end">
                <div className="max-w-[200px] md:max-w-sm lg:max-w-3xl">
                  <div className="bg-white-100 relative flex shrink flex-row items-center justify-between rounded-bl-[20px] rounded-tl-[20px] rounded-tr-[20px] bg-online bg-opacity-30 px-4 py-2 pr-6">
                    <div className="text-left text-[16px] text-gray-500 dark:text-gray-400">
                      Yes, I am at Istabu.
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-end">
                <DoubleTickIcon className="h-[16px] w-[16px] text-blue-600" />
                <div className="ml-2 mt-1 text-[10px] text-gray-500 dark:text-gray-400">
                  Rehan Wango - 01 Jan 2023.4.23
                </div>
              </div>
            </div>

            <div className="mt-4 flex h-full flex-row gap-2">
              <div className="flex items-end justify-center">
                <div className="h-[50px] w-[50px]">
                  <Image
                    alt="avatar"
                    quality={100}
                    objectFit="cover"
                    src={sampleAvatar1}
                    className="rounded-full bg-light-500 dark:bg-dark-300"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <div className="bg-white-100 relative flex shrink flex-row items-center justify-between rounded-tl-[20px] rounded-tr-[20px] rounded-br-[20px] bg-light-400 px-4 py-2 pr-6  dark:bg-dark-400">
                  <div className="text-left text-[16px] text-gray-500 dark:text-gray-400">
                    OoOo, Yeah, Thanks really Cool!
                  </div>
                </div>
                <div className="bg-white-100 relative flex shrink flex-row items-center justify-between rounded-tl-[20px] rounded-tr-[20px] rounded-br-[20px] bg-light-400 px-4 py-2 pr-6  dark:bg-dark-400">
                  <div className="text-left text-[16px] text-gray-500 dark:text-gray-400">
                    OoOo, Yeah, Thanks really Cool!
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 flex flex-col">
              <p className="mb-2 items-center truncate text-center text-sm text-gray-500 dark:text-gray-400">
                Thursday 24, 2022
              </p>
            </div>

            <div className="mt-4 flex h-full flex-row gap-2">
              <div className="flex items-end justify-center">
                <div className="h-[50px] w-[50px]">
                  <Image
                    alt="avatar"
                    quality={100}
                    objectFit="cover"
                    src={sampleAvatar1}
                    className="rounded-full bg-light-500 dark:bg-dark-300"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <div className="bg-white-100 relative flex shrink flex-row items-center justify-between rounded-tl-[20px] rounded-tr-[20px] rounded-br-[20px] bg-light-400 px-4 py-2 pr-6  dark:bg-dark-400">
                  <div className="text-left text-[16px] text-gray-500 dark:text-gray-400">
                    OoOo, Yeah, Thanks really Cool!
                  </div>
                </div>
                <div className="bg-white-100 relative flex shrink flex-row items-center justify-between rounded-tl-[20px] rounded-tr-[20px] rounded-br-[20px] bg-light-400 px-4 py-2 pr-6  dark:bg-dark-400">
                  <div className="text-left text-[16px] text-gray-500 dark:text-gray-400">
                    OoOo, Yeah, Thanks really Cool!
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 flex flex-col">
              <div className="flex flex-row items-center justify-end">
                <div className="bg-white-100 relative flex shrink flex-row items-center justify-between rounded-bl-[20px] rounded-tl-[20px] rounded-tr-[20px] bg-online bg-opacity-30 px-4 py-2 pr-6">
                  <div className="text-left text-[16px] text-gray-500 dark:text-gray-400">
                    Yes, I am at Istabu.
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-end">
                <DoubleTickIcon className="h-[16px] w-[16px] text-blue-600" />
                <div className="ml-2 mt-1 text-[10px] text-gray-500 dark:text-gray-400">
                  Rehan Wango - 01 Jan 2023.4.23
                </div>
              </div>
            </div>
          </div>
        </Scrollbar>

        <div className="flex w-full flex-row items-center justify-center gap-2 border-t-[1px] border-light-400 py-2 px-4 dark:border-dark-300">
          <div className="items-center justify-center">
            <Button
              variant="icon"
              aria-label="Search"
              className="h-[40px] w-[40px] rounded-full bg-dark-400"
            >
              <AttachmentIcon className="h-[16px] w-[16px]" />
            </Button>
          </div>

          <div className="flex-1 items-center justify-center">
            <input
              onChange={(e) => setMessageText(e.target.value)}
              autoFocus={true}
              placeholder="Send message"
              className="border-dark-30 h-full w-full border-0 bg-transparent bg-light  pl-2 text-13px outline-none focus:ring-0 dark:bg-dark-100"
            />
          </div>

          <div className="flex flex-row items-center justify-center gap-2">
            <Button
              variant="icon"
              aria-label="Search"
              className="h-[40px] w-[40px]"
            >
              <SendIcon className="h-[16px] w-[16px]" />
            </Button>
            <Button
              variant="icon"
              aria-label="Search"
              className="h-[40px] w-[40px] rounded-full bg-gradient-to-b from-online to-gradient"
            >
              <SpeechIcon className="h-[16px] w-[16px] text-white" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatContent;
