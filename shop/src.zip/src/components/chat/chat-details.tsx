import { useTranslation } from 'next-i18next';
import Input from '@/components/ui/forms/input';
import { useState } from 'react';
import { SettingsIcon } from '@/components/icons/chat/settings-icon';
import { PDFIcon } from '@/components/icons/chat/pdf-icon';
import { ImageIcon } from '@/components/icons/chat/image-icon';
import { VideoIcon } from '@/components/icons/chat/video-icon';
import { FigmaIcon } from '@/components/icons/chat/figma-icon';
import { StarIcon } from '@/components/icons/chat/star-icon';
import { DoubleTickIcon } from '@/components/icons/chat/double-tick-icon';
import Scrollbar from '@/components/ui/scrollbar';

import Image from '@/components/ui/image';
import Button from '@/components/ui/button';

import sampleAvatar1 from '@/assets/images/avatars/1.png';
import sampleMedia1 from '@/assets/images/medias/1.png';
import sampleMedia2 from '@/assets/images/medias/2.png';
import sampleMedia3 from '@/assets/images/medias/3.png';

const ChatDetails = () => {
  const { t } = useTranslation('common');
  let [searchText, setSearchText] = useState('');

  const onSeeAllMedias = () => {};

  return (
    <div className="hidden h-full w-full max-w-[395px] lg:block lg:w-[30%]">
      <div className="flex h-full flex-col">
        <div className="mt-10 py-3 px-4 sm:py-4">
          <div className="flex items-center space-x-2">
            <div className="flex-shrink-0">
              <div className="h-[50px] w-[50px]">
                <Image
                  alt="avatar"
                  quality={100}
                  objectFit="cover"
                  src={sampleAvatar1}
                  className="rounded-full bg-light-500 dark:bg-dark-300"
                />
              </div>
            </div>
            <div className="min-w-0 flex-1">
              <p className="mb-2 min-w-0 items-center truncate text-xl font-medium text-gray-900 dark:text-white">
                Neil Sims
              </p>

              <div className="flex min-w-0 flex-row items-center">
                <p className="mb-2 items-center truncate text-sm text-gray-500 dark:text-gray-400">
                  Active Now
                </p>
                <p className="-mt-2 ml-1 inline-flex min-h-[16px] min-w-[16px] shrink-0 items-center justify-center rounded-full border-2 border-light-100 bg-brand px-0.5 text-10px font-bold leading-none text-light dark:border-dark-250" />
              </div>
            </div>
            <div className="inline-flex text-xs font-semibold text-gray-500 dark:text-gray-400">
              <SettingsIcon className="h-[20px] w-[20px] text-dark-800" />
            </div>
          </div>
        </div>
        <Scrollbar className="relative mt-10 h-full w-full">
          <div className="flex w-full flex-col px-4">
            <div className="sticky top-0 z-20 flex flex-row items-center justify-between bg-white dark:bg-dark-100">
              <div className="flex shrink flex-row items-center">
                <div className="text-xl text-black dark:text-white">Media</div>
                <div className="ml-2 mt-1 text-[10px] text-gray-500 dark:text-gray-400">
                  20
                </div>
              </div>
              <button
                className="flex items-center justify-center hover:bg-opacity-10"
                onClick={onSeeAllMedias}
              >
                <p className="text-[10px] text-gray-500 dark:text-gray-400">
                  See All
                </p>
              </button>
            </div>

            <div className="mt-4 grid grid-cols-3 gap-4">
              <Image
                alt="avatar"
                quality={100}
                objectFit="cover"
                src={sampleMedia1}
                className="rounded-[16px] bg-light-500 dark:bg-dark-300"
              />
              <Image
                alt="avatar"
                quality={100}
                objectFit="cover"
                src={sampleMedia2}
                className="rounded-[16px] bg-light-500 dark:bg-dark-300"
              />
              <Image
                alt="avatar"
                quality={100}
                objectFit="cover"
                src={sampleMedia3}
                className="rounded-[16px] bg-light-500 dark:bg-dark-300"
              />
            </div>

            <div className="sticky top-0 z-20 mt-10 flex flex-row items-center justify-between bg-white dark:bg-dark-100">
              <div className="flex shrink flex-row items-center">
                <div className="text-xl text-black dark:text-white">Files</div>
                <div className="ml-2 mt-1 text-[10px] text-gray-500 dark:text-gray-400">
                  20
                </div>
              </div>
              <button
                className="flex items-center justify-center hover:bg-opacity-10"
                onClick={onSeeAllMedias}
              >
                <p className="text-[10px] text-gray-500 dark:text-gray-400">
                  See All
                </p>
              </button>
            </div>

            <ul role="list" className="mt-4">
              <li className="py-3 sm:py-2">
                <div className="flex items-center space-x-2">
                  <div className="flex-shrink-0">
                    <div className="flex h-[38px] w-[38px] items-center justify-center rounded-full bg-red-500">
                      <PDFIcon className="h-[20px] w-[20px] text-white" />
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="mb-1 min-w-0 items-center truncate text-sm font-medium text-gray-900 dark:text-white">
                      Whitepaper.pdf
                    </p>
                    <p className="flex items-center truncate text-[10px] text-gray-500 dark:text-gray-400">
                      3.7MB
                      <svg
                        width="2"
                        height="2"
                        fill="currentColor"
                        className="mx-2 text-slate-300"
                        aria-hidden="true"
                      >
                        <circle cx="1" cy="1" r="1" />
                      </svg>
                      22, Jan 2021
                    </p>
                  </div>
                </div>
              </li>
              <li className="py-3 sm:py-2">
                <div className="flex items-center space-x-2">
                  <div className="flex-shrink-0">
                    <div className="flex h-[38px] w-[38px] items-center justify-center rounded-full bg-green-500">
                      <ImageIcon className="h-[20px] w-[20px] text-white" />
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="mb-1 min-w-0 items-center truncate text-sm font-medium text-gray-900 dark:text-white">
                      Logo.jpg
                    </p>
                    <p className="flex items-center truncate text-[10px] text-gray-500 dark:text-gray-400">
                      3.7MB
                      <svg
                        width="2"
                        height="2"
                        fill="currentColor"
                        className="mx-2 text-slate-300"
                        aria-hidden="true"
                      >
                        <circle cx="1" cy="1" r="1" />
                      </svg>
                      22, Jan 2021
                    </p>
                  </div>
                </div>
              </li>
              <li className="py-3 sm:py-2">
                <div className="flex items-center space-x-2">
                  <div className="flex-shrink-0">
                    <div className="flex h-[38px] w-[38px] items-center justify-center rounded-full bg-blue-500">
                      <VideoIcon className="h-[20px] w-[20px] text-white" />
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="mb-1 min-w-0 items-center truncate text-sm font-medium text-gray-900 dark:text-white">
                      Pargy.mp4
                    </p>
                    <p className="flex items-center truncate text-[10px] text-gray-500 dark:text-gray-400">
                      3.7MB
                      <svg
                        width="2"
                        height="2"
                        fill="currentColor"
                        className="mx-2 text-slate-300"
                        aria-hidden="true"
                      >
                        <circle cx="1" cy="1" r="1" />
                      </svg>
                      22, Jan 2021
                    </p>
                  </div>
                </div>
              </li>
              <li className="py-3 sm:py-2">
                <div className="flex items-center space-x-2">
                  <div className="flex-shrink-0">
                    <div className="flex h-[38px] w-[38px] items-center justify-center rounded-full bg-yellow-500">
                      <FigmaIcon className="h-[20px] w-[20px] text-white" />
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="mb-1 min-w-0 items-center truncate text-sm font-medium text-gray-900 dark:text-white">
                      Design.fig
                    </p>
                    <p className="flex items-center truncate text-[10px] text-gray-500 dark:text-gray-400">
                      3.7MB
                      <svg
                        width="2"
                        height="2"
                        fill="currentColor"
                        className="mx-2 text-slate-300"
                        aria-hidden="true"
                      >
                        <circle cx="1" cy="1" r="1" />
                      </svg>
                      22, Jan 2021
                    </p>
                  </div>
                </div>
              </li>
            </ul>

            <div className="sticky top-0 z-20 mt-10 flex flex-row items-center justify-between bg-white dark:bg-dark-100">
              <div className="flex shrink flex-row items-center">
                <div className="text-xl text-black dark:text-white">
                  Star Message
                </div>
                <div className="ml-2 mt-1 text-[10px] text-gray-500 dark:text-gray-400">
                  20
                </div>
              </div>
              <button
                className="flex items-center justify-center hover:bg-opacity-10"
                onClick={onSeeAllMedias}
              >
                <p className="text-[10px] text-gray-500 dark:text-gray-400">
                  See All
                </p>
              </button>
            </div>

            <div className="flex flex-col">
              <div className="mt-4 flex w-full flex-col">
                <div className="bg-white-100 relative flex w-full shrink flex-row items-center justify-between rounded-tl-[20px] rounded-tr-[20px] rounded-br-[20px] bg-light-400 px-4 py-2 pr-6  dark:bg-dark-400">
                  <div className="text-left text-[16px] text-gray-500 dark:text-gray-400">
                    OoOo, Yeah, Thanks really Cool!
                  </div>
                  <StarIcon className="absolute top-3.5 right-3 h-[12px] w-[12px] text-white" />
                </div>
                <div className="flex items-center">
                  <DoubleTickIcon className="h-[16px] w-[16px] text-blue-600" />
                  <div className="ml-2 mt-1 text-[10px] text-gray-500 dark:text-gray-400">
                    Rehan Wango - 01 Jan 2023.4.23
                  </div>
                </div>
              </div>

              <div className="mt-4 flex w-full flex-col">
                <div className="bg-white-100 relative flex w-full shrink flex-row items-center justify-between rounded-bl-[20px] rounded-tl-[20px] rounded-tr-[20px] bg-online bg-opacity-30 px-4 py-2 pr-6">
                  <div className="text-left text-[16px] text-gray-500 dark:text-gray-400">
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry
                  </div>
                  <StarIcon className="absolute top-3.5 right-3 h-[12px] w-[12px] text-white" />
                </div>
                <div className="flex items-center justify-end">
                  <DoubleTickIcon className="h-[16px] w-[16px] text-blue-600" />
                  <div className="ml-2 mt-1 text-[10px] text-gray-500 dark:text-gray-400">
                    Rehan Wango - 01 Jan 2023.4.23
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Scrollbar>
      </div>
    </div>
  );
};

export default ChatDetails;
