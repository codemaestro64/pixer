INSERT INTO `tax_classes` (`id`, `country`, `state`, `zip`, `city`, `rate`, `name`, `is_global`, `priority`, `on_shipping`, `created_at`, `updated_at`) VALUES
(1, 'United States', 'California', '90017', 'Los Angeles', 5, 'Qubitron Solutions', NULL, NULL, 1, '2022-02-19 16:55:46', '2022-02-20 06:45:40');
