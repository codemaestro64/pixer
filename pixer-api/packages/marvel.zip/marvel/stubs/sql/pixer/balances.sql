INSERT INTO `balances` (`id`, `shop_id`, `admin_commission_rate`, `total_earnings`, `withdrawn_amount`, `current_balance`, `payment_info`, `created_at`, `updated_at`) VALUES
(1, 1, 10, 310.5, 124.2, 186.3, '{\"bank\": null, \"name\": null, \"email\": \"admin@example.com\"}', '2022-01-22 16:30:50', '2022-02-24 04:56:16'),
(2, 2, 10, 79.2, 0, 79.2, '{\"bank\": null, \"name\": null, \"email\": \"rnb@rnc.rnd\"}', '2022-01-22 16:51:34', '2022-02-20 06:24:39'),
(3, 3, 10, 171.891, 0, 171.891, '{\"bank\": null, \"name\": null, \"email\": \"furniture_shop@demo.com\"}', '2022-01-22 16:53:14', '2022-02-19 12:09:26'),
(4, 4, 10, 1286.1, 0, 1286.1, '{\"bank\": null, \"name\": null, \"email\": \"admin@example.com\"}', '2022-01-26 08:55:45', '2022-05-11 08:10:25'),
(5, 5, 10, 549.9, 0, 549.9, '{\"bank\": null, \"name\": null, \"email\": \"shop_owner@demo.com\"}', '2022-01-26 09:00:06', '2022-05-11 08:10:25'),
(6, 6, 10, 1033.2, 0, 1033.2, '{\"bank\": null, \"name\": null, \"email\": \"admin@example.com\"}', '2022-01-26 15:51:40', '2022-05-11 08:10:25'),
(7, 7, 15, 453.9, 0, 453.9, '{\"bank\": null, \"name\": null, \"email\": \"admin@example.com\"}', '2022-01-26 15:53:03', '2022-05-11 08:10:24'),
(8, 8, 20, 1396, 0, 1396, '{\"bank\": null, \"name\": null, \"email\": \"rnb@rnc.rnd\"}', '2022-01-26 15:54:49', '2022-05-11 08:10:25'),
(9, 9, 10, 856.8, 435, 421.8, '{\"bank\": \"demo\", \"name\": \"demo\", \"email\": \"shop_owner@demo.com\", \"account\": 1231321321}', '2022-01-26 15:56:04', '2022-05-11 08:10:25');
